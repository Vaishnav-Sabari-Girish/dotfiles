mod gradient;

pub(crate) use gradient::SubCommand as Gradient;
