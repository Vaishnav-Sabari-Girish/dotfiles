# nu-path

This crate takes care of path handling in Nushell, such as canonicalization and component expansion, as well as other path-related utilities.
