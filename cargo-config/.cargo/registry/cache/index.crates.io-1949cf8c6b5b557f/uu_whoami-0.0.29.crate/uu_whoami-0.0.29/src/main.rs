uucore::bin!(uu_whoami);
