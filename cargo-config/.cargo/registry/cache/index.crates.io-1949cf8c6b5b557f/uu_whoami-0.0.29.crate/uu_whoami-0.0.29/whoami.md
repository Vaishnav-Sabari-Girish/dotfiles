# whoami

```
whoami
```

Print the current username.
