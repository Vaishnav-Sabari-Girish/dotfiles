//! Mailslots – a Windows-specific IPC primitive designed for short multiple-producer-single-consumer message communication with UDP reliability guarantees, which works both on the local system or across the network.

// TODO this thing
