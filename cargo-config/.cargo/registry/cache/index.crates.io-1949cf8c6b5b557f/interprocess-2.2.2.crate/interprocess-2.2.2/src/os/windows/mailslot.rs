//! Windows-specific IPC primitive designed for short multiple-producer-single-consumer message
//! communication with UDP reliability guarantees, which works both on the local system and across
//! the network.

// TODO(2.4.0) this thing
