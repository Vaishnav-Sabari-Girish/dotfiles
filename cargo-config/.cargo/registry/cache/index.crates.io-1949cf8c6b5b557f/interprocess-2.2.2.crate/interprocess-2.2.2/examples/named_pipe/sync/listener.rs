//{
// TODO(2.3.0)
#[cfg(not(windows))]
fn main() {}
#[cfg(windows)]
fn main() -> std::io::Result<()> {
	//}
	//{
	Ok(())
} //}
