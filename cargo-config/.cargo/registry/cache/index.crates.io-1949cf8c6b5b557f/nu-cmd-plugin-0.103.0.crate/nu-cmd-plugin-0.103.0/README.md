# nu-cmd-plugin

This crate implements Nushell commands related to plugin management.
