# uname

```
uname [OPTION]...
```

Print certain system information. 
With no OPTION, same as -s.
