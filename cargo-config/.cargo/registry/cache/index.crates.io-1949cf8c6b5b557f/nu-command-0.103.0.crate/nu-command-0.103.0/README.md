This crate contains the majority of our commands

We allow ourselves to move some of the commands in `nu-command` to `nu-cmd-*` crates as needed.

## Internal Nushell crate

This crate implements components of Nushell and is not designed to support plugin authors or other users directly.
