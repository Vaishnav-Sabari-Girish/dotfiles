Implementation of the Nushell language server.

See [the Language Server Protocol specification](https://microsoft.github.io/language-server-protocol/)

## Internal Nushell crate

This crate implements components of Nushell and is not designed to support plugin authors or other users directly.
