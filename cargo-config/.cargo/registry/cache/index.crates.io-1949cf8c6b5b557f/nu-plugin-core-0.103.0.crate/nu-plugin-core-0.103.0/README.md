# nu-plugin-core

This crate provides functionality that is shared by the [Nushell](https://nushell.sh/) engine and plugins.
