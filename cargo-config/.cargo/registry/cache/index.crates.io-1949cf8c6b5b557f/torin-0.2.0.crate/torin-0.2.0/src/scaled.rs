pub trait Scaled {
    fn scale(&mut self, scale_factor: f32);
}
