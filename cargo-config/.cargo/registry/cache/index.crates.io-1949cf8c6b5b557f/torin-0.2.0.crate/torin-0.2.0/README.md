# torin 📐

<a href="https://freyaui.dev/"><img align="right" src="../../logo.svg" alt="Freya logo" width="150"/></a>

[![Discord Server](https://img.shields.io/discord/1015005816094478347.svg?logo=discord&style=flat-square)](https://discord.gg/sYejxCdewG)
[![Github Sponsors](https://img.shields.io/github/sponsors/marc2332?style=social)](https://github.com/sponsors/marc2332)
[![codecov](https://codecov.io/github/marc2332/freya/branch/main/graph/badge.svg?token=APSGEC84B8)](https://codecov.io/github/marc2332/freya)

[Website](https://freyaui.dev) | [Discord](https://discord.gg/sYejxCdewG)

**Torin** 📐 is a pure Rust 🦀 layout library I made for **Freya** 🟣, a native GUI library for Rust. But it can work with other libraries too, see a Demo in the `demo.rs` example.
