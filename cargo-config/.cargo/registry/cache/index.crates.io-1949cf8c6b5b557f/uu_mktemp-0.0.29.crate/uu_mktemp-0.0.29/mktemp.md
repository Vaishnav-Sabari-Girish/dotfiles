# mktemp

```
mktemp [OPTION]... [TEMPLATE]
```

Create a temporary file or directory.
