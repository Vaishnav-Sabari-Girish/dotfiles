use binread::BinRead;

#[derive(BinRead)]
enum UnitEnum {
    A,
}

fn main() {}
