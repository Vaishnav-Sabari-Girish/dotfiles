mod derive {
    mod enums;
    mod struct_generic;
    mod struct_map;
    mod structs;
    mod unit_enum;
    mod unit_struct;
}
