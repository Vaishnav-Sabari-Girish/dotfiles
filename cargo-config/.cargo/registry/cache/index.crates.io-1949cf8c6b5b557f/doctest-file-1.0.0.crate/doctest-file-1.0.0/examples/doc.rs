//{
use crate::plus_1;
#[test]
fn testmain() {
	//}
	println!("plus_1(1) = {}", plus_1(1)); // prints 2
} //
