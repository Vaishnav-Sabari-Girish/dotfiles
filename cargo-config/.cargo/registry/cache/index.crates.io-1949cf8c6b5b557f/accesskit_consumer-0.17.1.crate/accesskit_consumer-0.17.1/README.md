# AccessKit consumer library

This library is used by code that consumes AccessKit accessibility trees, such as platform adapters. It does not need to be used directly by applications integrating AccessKit.
