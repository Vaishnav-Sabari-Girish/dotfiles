//! It should be possible to swap out templates at runtime, enabling hotreloading
