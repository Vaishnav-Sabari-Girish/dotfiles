/// Timestamp used to clear tracking information.
#[derive(Clone, Copy)]
pub struct TrackingTimestamp(pub(crate) u32);
