pub trait Sealed {}
