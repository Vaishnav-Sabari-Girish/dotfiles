# Going Further

This section covers patterns that are not needed for all projects but come in handy when the situation requires it.
