# Going Further

This section covers more advanced topics. Topics include parallelism, and how everything behaves so you can avoid surprises.
