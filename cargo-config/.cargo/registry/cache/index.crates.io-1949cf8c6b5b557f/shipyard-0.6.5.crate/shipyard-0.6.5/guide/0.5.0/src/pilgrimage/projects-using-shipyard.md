# Projects using Shipyard

List of project using Shipyard.  
Don't hesitate to contact me to get your project listed.

- [Almetica](https://github.com/almetica/almetica) is a server for the MMORPG TERA.
- [Guacamole Runner](https://github.com/BoxyUwU/guacamole-runner) by [@BoxyUwU](https://github.com/BoxyUwU) is a small game where the player is constantly falling and must jump off planes to stay in the air. When they go over the top of the dirt tiles they plant flowers which gives them points.
