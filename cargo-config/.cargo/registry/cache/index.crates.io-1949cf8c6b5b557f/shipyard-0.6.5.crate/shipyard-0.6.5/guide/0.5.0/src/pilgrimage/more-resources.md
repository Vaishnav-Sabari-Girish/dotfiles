# More Resources

[Packs](https://skypjack.github.io/2019-03-21-ecs-baf-part-2-insights/), the whole series is a good read  
[Timothy Ford's GDC talk on ECS usage in Overwatch](https://www.youtube.com/watch?v=W3aieHjyNvw)  
[Catherine West's closing keynote on using the ECS pattern in Rust](https://www.youtube.com/watch?v=aKLntZcp27M)  
[Sander Mertens's ECS FAQ](https://github.com/SanderMertens/ecs-faq)  
[FSM in ECS](https://www.richardlord.net/blog/ecs/finite-state-machines-with-ash.html)  
[Todo MVC using ECS](https://github.com/abulka/todomvc-ecs)  
