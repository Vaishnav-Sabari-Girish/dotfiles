# Delete Entity

Deleting an entity deletes it from the entities storage, while also deleting all its components.

## World

```rust, noplaypen
{{#include ../../../../tests/book/delete_entity.rs:world}}
```

## View

```rust, noplaypen
{{#include ../../../../tests/book/delete_entity.rs:view}}
```
