# Fundamentals

## Getting Started

For most target architectures you can just add it to `Cargo.toml`.

For single-threaded environments (like WASM) or embedded you'll need to turn off default features and add features back in when needed.

Now that we're ready to use Shipyard, let's learn the basics!
