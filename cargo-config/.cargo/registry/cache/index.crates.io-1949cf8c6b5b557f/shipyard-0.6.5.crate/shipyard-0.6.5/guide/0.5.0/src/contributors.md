# Guide Contributors

[dakom - David Komer](https://github.com/dakom)  
[eldyer](https://github.com/eldyer)  
