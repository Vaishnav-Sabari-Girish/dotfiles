# Going Further

This section covers the inner working of shipyard. As a user you don't need to know any of this to leverage everything shipyard can offer.

If you want to contribute or make your own ECS this section can be handy.
