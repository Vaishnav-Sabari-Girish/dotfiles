# nu-plugin-engine

This crate provides functionality for the [Nushell](https://nushell.sh/) engine to spawn and interact with plugins.
