#[deprecated(since = "0.68.0", note = "use docs::pdf::DateTime")]
pub use crate::docs::pdf::DateTime;
