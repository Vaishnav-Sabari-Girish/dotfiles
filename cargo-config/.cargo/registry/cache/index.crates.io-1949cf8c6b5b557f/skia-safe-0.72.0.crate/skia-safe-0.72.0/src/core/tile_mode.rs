pub use skia_bindings::SkTileMode as TileMode;
variant_name!(TileMode::Mirror);
