// TODO: wrap SkTraceMemoryDump
