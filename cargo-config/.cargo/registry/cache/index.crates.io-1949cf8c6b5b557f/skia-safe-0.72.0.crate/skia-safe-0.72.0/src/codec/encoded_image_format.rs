pub use skia_bindings::SkEncodedImageFormat as EncodedImageFormat;
variant_name!(EncodedImageFormat::BMP);
