pub(crate) mod safe32;
