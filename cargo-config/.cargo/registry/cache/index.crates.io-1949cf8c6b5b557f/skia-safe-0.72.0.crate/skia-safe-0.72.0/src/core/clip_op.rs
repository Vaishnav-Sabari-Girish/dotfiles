pub use skia_bindings::SkClipOp as ClipOp;
variant_name!(ClipOp::Difference);
