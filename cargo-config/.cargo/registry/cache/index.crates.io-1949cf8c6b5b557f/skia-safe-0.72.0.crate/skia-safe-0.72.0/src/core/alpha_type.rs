pub use skia_bindings::SkAlphaType as AlphaType;
variant_name!(AlphaType::Premul);
