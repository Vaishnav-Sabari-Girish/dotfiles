pub use skia_bindings::SkCoverageMode as CoverageMode;
variant_name!(CoverageMode::Union);
