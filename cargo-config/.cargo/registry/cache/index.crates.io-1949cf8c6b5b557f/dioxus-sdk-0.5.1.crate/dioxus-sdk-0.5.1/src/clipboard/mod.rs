mod use_clipboard;

pub use use_clipboard::*;
