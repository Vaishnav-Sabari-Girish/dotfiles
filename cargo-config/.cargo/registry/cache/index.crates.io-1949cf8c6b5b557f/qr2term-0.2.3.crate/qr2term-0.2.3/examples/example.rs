fn main() {
    qr2term::print_qr("https://rust-lang.org/").unwrap();
}
