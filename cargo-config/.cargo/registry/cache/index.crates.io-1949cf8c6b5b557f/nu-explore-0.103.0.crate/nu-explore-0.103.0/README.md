Implementation of the interactive `explore` command pager.

## Internal Nushell crate

This crate implements components of Nushell and is not designed to support plugin authors or other users directly.
