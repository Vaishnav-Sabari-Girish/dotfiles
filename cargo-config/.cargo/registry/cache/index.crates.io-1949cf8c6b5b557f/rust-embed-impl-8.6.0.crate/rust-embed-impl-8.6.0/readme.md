# Rust Embed Implementation

The implementation of the rust-embed macro lies here.
