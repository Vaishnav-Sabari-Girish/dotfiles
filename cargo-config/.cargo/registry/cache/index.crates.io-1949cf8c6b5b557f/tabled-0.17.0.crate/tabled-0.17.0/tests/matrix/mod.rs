#[allow(clippy::module_inception)]
mod matrix;
mod matrix_list;

pub use matrix::Matrix;
pub use matrix_list::MatrixList;
