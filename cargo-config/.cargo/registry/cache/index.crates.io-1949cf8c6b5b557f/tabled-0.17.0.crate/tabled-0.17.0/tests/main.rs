mod core;
mod derive;
mod macros;
mod settings;

#[cfg(feature = "std")]
mod matrix;
