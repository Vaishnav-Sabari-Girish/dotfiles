pub use papergrid::config::compact::CompactConfig;
