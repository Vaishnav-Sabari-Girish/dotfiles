Implementation of the layout engine for the `grid` command.

## Internal Nushell crate

This crate implements components of Nushell and is not designed to support plugin authors or other users directly.
