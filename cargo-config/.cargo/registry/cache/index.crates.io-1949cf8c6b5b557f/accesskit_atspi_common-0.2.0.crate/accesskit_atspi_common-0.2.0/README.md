# AccessKit common AT-SPI translation layer

This crate contains common logic for translating between AccessKit and AT-SPI. It is shared by the AccessKit Unix adapter and the new, experimental GNOME accessibility stack (code-named Newton) which is based on pushing AccessKit tree updates to the assistive technology.
