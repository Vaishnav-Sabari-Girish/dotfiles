# Developer Notes

This is a collection of additional documentation about the design decisions made in the development of `serialport-rs`.