```console
$ 02_crate_derive --help
clap [..]
A simple to use, efficient, and full-featured Command Line Argument Parser

USAGE:
    02_crate_derive[EXE] --two <TWO> --one <ONE>

OPTIONS:
    -h, --help         Print help information
        --one <ONE>    
        --two <TWO>    
    -V, --version      Print version information

$ 02_crate_derive --version
clap [..]

```
