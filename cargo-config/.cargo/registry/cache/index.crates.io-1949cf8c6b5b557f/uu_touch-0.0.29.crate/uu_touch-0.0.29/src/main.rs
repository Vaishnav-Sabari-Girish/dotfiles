uucore::bin!(uu_touch);
