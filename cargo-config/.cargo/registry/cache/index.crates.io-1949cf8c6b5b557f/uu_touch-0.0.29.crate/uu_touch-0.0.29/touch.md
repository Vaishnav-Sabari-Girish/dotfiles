# touch

```
touch [OPTION]... [USER]
```

Update the access and modification times of each `FILE` to the current time.
