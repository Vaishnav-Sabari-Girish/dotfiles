
# Change Log

## Version 0.1.1 (30.03.2019 14:49)

Added `lines!` macro.

## Version 0.1.0 (30.03.2019)

Added map/set macros:

- `hash_map!`
- `hash_set!`
- `b_tree_map!`
- `b_tree_set`

Added expr counting macro for `with_capacity`
constructors, `reserve` methods and similar:

- `const_expr_count!`