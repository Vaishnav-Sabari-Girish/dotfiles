# mkdir

<!-- spell-checker:ignore ugoa -->

```
mkdir [OPTION]... DIRECTORY...
```

Create the given DIRECTORY(ies) if they do not exist

## After Help

Each MODE is of the form '[ugoa]*([-+=]([rwxXst]*|[ugo]))+|[-+=]?[0-7]+'.
