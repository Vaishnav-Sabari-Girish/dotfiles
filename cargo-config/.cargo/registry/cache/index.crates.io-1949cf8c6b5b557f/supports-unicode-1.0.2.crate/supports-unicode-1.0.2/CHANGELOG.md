# `supports-unicode` Release Changelog

<a name="1.0.2"></a>
## 1.0.2 (2021-09-27)

### Bug Fixes

* **linux:** Ignore case when detecting UTF-8 locales. (#1) ([38082d27](https://github.com/zkat/supports-unicode/commit/38082d27b13c6c3289cc126babeb8b20e2f72d3b))

<a name="1.0.1"></a>
## 1.0.1 (2021-09-11)

### Bug Fixes

* **cargo:** fix stuff in cargo.toml ([bcabb6ab](https://github.com/zkat/supports-unicode/commit/bcabb6ab3540e8cd3ce8cf8de51c00fe531936fe))

<a name="1.0.0"></a>
## 1.0.0 (2021-09-11)

### Features

* **api:** initial commit ([0b57e63a](https://github.com/zkat/supports-unicode/commit/0b57e63a443d4aab57ecf24868394e0d06984465))

