Collection of small utilities that are shared across Nushell crates.

This crate should compile early in the crate graph and thus not depend on major dependencies or core-nushell crates itself.
## Internal Nushell crate

This crate implements components of Nushell and is not designed to support plugin authors or other users directly.
