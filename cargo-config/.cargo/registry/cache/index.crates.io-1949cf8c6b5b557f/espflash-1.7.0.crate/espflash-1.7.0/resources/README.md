# Espflash Resources

The bootloaders have been built by hand from ESP-IDF:  
https://github.com/espressif/esp-idf

The flasher stubs are taken from the **espressif/esptool** repository:  
https://github.com/espressif/esptool/tree/master/esptool/targets/stub_flasher
