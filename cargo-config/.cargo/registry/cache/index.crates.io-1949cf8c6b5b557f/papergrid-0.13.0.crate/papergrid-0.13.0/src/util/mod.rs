//! A module contains utility functions which grid relay on.

pub mod string;
