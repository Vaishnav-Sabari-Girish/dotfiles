#!/bin/sh
wasm-pack build --scope paddim8 -- --no-default-features
