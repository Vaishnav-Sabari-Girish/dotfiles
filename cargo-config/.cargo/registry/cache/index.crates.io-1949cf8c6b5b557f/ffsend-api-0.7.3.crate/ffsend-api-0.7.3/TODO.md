# TODO
- Somehow implement openssl_probe to prove for certificates
- Trigger `ffsend` once `ffsend-api` succeeds
- Rework encrypted reader/writer
- API actions contain duplicate code, create centralized functions
- Make sure errors aren't too verbose
- Better expose all errors, and box chained errors
- Properly document all code components
