//! ### Inheritance
//!
//! These are some attribute that are inherited from the element parents:
//!
//! - `color`
//! - `font_family`
//! - `font_size`
//! - `font_style`
//! - `font_weight`
//! - `font_width`
//! - `line_height`
//! - `align`
//! - `max_lines`
//! - `letter_spacing`
//! - `word_spacing`
//! - `decoration`
//! - `decoration_style`
//! - `decoration_color`
//! - `text_shadow`
//!
