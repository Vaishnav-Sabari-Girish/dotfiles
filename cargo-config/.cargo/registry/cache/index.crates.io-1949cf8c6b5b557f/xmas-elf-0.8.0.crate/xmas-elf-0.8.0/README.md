# xmas-elf

A library for parsing and navigating ELF files.

* Pure Rust
* Zero allocation (minimal allocation for interpreting the data)
* Strongly, statically typed.


