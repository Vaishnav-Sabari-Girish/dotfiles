# 0.2.1 (January 6, 2019)

* Implement `Clone` for `TlsConnector` and `TlsAcceptor` (#777)

# 0.2.0 (August 8, 2018)

* Initial release with `tokio` support.
