## 0.14.0 - 2017-12-xx

- Make `.skip_on_notify()` default behaviour
- Clean tests to pass on Fedora

## 0.13.0 - 2017-09-06

- Add `.skip_on_notty()`
