<div>
  <h1>📦✨ Dioxus CLI Configuration</h1>
</div>

The **dioxus-cli-config** contains the configuration for the **dioxus-cli**.
