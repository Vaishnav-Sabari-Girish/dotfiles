This crate implements the core functionality of the interactive Nushell REPL and interfaces with `reedline`.
Currently implements the syntax highlighting and completions logic.
Furthermore includes a few commands that are specific to `reedline`

## Internal Nushell crate

This crate implements components of Nushell and is not designed to support plugin authors or other users directly.
