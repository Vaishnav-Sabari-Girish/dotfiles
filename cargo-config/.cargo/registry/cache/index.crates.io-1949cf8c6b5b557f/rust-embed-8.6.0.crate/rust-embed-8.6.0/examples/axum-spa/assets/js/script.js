var elem = document.createElement("div");
elem.innerHTML = "I'm the JS script!<br>" + new Date();
document.body.appendChild(elem);
