# dialoguer

[![Build Status](https://github.com/mitsuhiko/dialoguer/workflows/CI/badge.svg)](https://github.com/mitsuhiko/dialoguer/actions?query=branch%3Amaster)
[![Latest version](https://img.shields.io/crates/v/dialoguer.svg)](https://crates.io/crates/dialoguer)
[![Documentation](https://docs.rs/dialoguer/badge.svg)](https://docs.rs/dialoguer)

A rust library for command line prompts and similar things.
